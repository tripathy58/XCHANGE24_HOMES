$(document).ready(function() {
    if ($("#flashes *").length > 0){
      $("#modalId").modal();
    }
  });